import flet as ft

class CalcButton(ft.ElevatedButton):
    def __init__(self, text, button_clicked, expand=1):
        super().__init__()  # Inicializa o botão elevado
        self.text = text  # Texto do botão
        self.expand = expand  # Expansão do botão (proporção na grid)
        self.on_click = button_clicked  # Ação a ser realizada quando o botão é clicado
        self.data = text  # Armazena o texto do botão para uso posterior


class DigitButton(CalcButton):
    def __init__(self, text, button_clicked, expand=1):
        CalcButton.__init__(self, text, button_clicked, expand)  # Inicializa a classe base
        self.bgcolor = ft.colors.WHITE24  # Cor de fundo dos botões de dígitos
        self.color = ft.colors.WHITE  # Cor do texto


class ActionButton(CalcButton):
    def __init__(self, text, button_clicked):
        CalcButton.__init__(self, text, button_clicked)  # Inicializa a classe base
        self.bgcolor = ft.colors.ORANGE  # Cor de fundo dos botões de ação
        self.color = ft.colors.WHITE  # Cor do texto


class ExtraActionButton(CalcButton):
    def __init__(self, text, button_clicked):
        CalcButton.__init__(self, text, button_clicked)  # Inicializa a classe base
        self.bgcolor = ft.colors.BLUE_GREY_100  # Cor de fundo dos botões de ações extras
        self.color = ft.colors.BLACK  # Cor do texto


class CalculatorApp(ft.Container):
    # Classe principal da calculadora, que contém todos os controles
    def __init__(self):
        super().__init__()  # Inicializa o container
        self.reset()  # Reseta as variáveis da calculadora

        # Texto para exibir o resultado da calculadora
        self.result = ft.Text(value="0", color=ft.colors.WHITE, size=20)
        self.width = 350  # Largura da calculadora
        self.bgcolor = ft.colors.BLACK  # Cor de fundo da calculadora
        self.border_radius = ft.border_radius.all(20)  # Raio da borda
        self.padding = 20  # Preenchimento interno

        # Estrutura de controle da calculadora
        self.content = ft.Column(
            controls=[
                ft.Row(controls=[self.result], alignment="end"),  # Linha para exibir o resultado
                ft.Row(
                    controls=[  # Linha para botões de ações extras
                        ExtraActionButton(text="AC", button_clicked=self.button_clicked),
                        ExtraActionButton(text="+/-", button_clicked=self.button_clicked),
                        ExtraActionButton(text="%", button_clicked=self.button_clicked),
                        ActionButton(text="/", button_clicked=self.button_clicked),
                    ]
                ),
                ft.Row(controls=[  # Linha para dígitos e operação de multiplicação
                        DigitButton(text="7", button_clicked=self.button_clicked),
                        DigitButton(text="8", button_clicked=self.button_clicked),
                        DigitButton(text="9", button_clicked=self.button_clicked),
                        ActionButton(text="*", button_clicked=self.button_clicked),
                    ]),
                ft.Row(controls=[  # Linha para dígitos e operação de subtração
                        DigitButton(text="4", button_clicked=self.button_clicked),
                        DigitButton(text="5", button_clicked=self.button_clicked),
                        DigitButton(text="6", button_clicked=self.button_clicked),
                        ActionButton(text="-", button_clicked=self.button_clicked),
                    ]),
                ft.Row(controls=[  # Linha para dígitos e operação de adição
                        DigitButton(text="1", button_clicked=self.button_clicked),
                        DigitButton(text="2", button_clicked=self.button_clicked),
                        DigitButton(text="3", button_clicked=self.button_clicked),
                        ActionButton(text="+", button_clicked=self.button_clicked),
                    ]),
                ft.Row(controls=[  # Linha para dígito 0 e operação de igual
                        DigitButton(text="0", button_clicked=self.button_clicked),
                        DigitButton(text=".", button_clicked=self.button_clicked),
                        ActionButton(text="=", button_clicked=self.button_clicked),
                    ]),
            ]
        )

    def button_clicked(self, e):
        # Ação ao clicar em um botão
        data = e.control.data  # Obtém o texto do botão clicado
        print(f"Button clicked with data = {data}")  # Imprime o texto do botão no console

        # Reseta a calculadora se a ultima operação resultou em erro ou se "AC" foi clicado
        if self.result.value == "Error" or data == "AC":
            self.result.value = "0"  # Reseta o resultado para 0
            self.reset()  # Reseta variáveis internas

        # Verifica se um dígito ou ponto decimal foi clicado
        elif data in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "."):
            if self.result.value == "0" or self.new_operand:
                self.result.value = data  # Substitui o resultado atual
                self.new_operand = False  # Indica que não é um novo operando
            else:
                self.result.value = self.result.value + data  # Adiciona o dígito ao resultado

        # Verifica se uma operação foi clicada
        elif data in ("+", "-", "*", "/"):
            self.operand1 = float(self.result.value)  # Armazena o valor atual
            self.operator = data  # Atualiza o operador atual
            self.new_operand = True  # Prepara para um novo operando

        # Ação ao clicar no botão de igual
        elif data == "=":
            self.result.value = self.calculate(
                self.operand1, float(self.result.value), self.operator
            )  # Calcula o resultado final
            self.reset()  # Reseta as variáveis internas

        # Ação ao clicar no botão de porcentagem
        elif data == "%":
            self.result.value = str(float(self.result.value) / 100)  # Calcula a porcentagem
            self.reset()  # Reseta as variáveis internas

        # Ação ao clicar no botão de troca de sinal
        elif data == "+/-":
            if float(self.result.value) > 0:
                self.result.value = "-" + self.result.value  # Converte para negativo
            elif float(self.result.value) < 0:
                self.result.value = self.result.value[1:]  # Remove o sinal negativo

        self.update()  # Atualiza a interface da calculadora

    def calculate(self, operand1, operand2, operator):
        # Função para realizar cálculos com base no operador
        if operator == "+":
            return str(self.format_number(operand1 + operand2))  # Adição
        elif operator == "-":
            return str(self.format_number(operand1 - operand2))  # Subtração
        elif operator == "*":
            return str(self.format_number(operand1 * operand2))  # Multiplicação
        elif operator == "/":
            if operand2 == 0:
                return "Error"  # Evita divisão por zero
            else:
                return str(self.format_number(operand1 / operand2))  # Divisão

    def format_number(self, num):
        # Formata o número para remover casas decimais desnecessárias
        if num % 1 == 0:
            return int(num)  # Retorna como inteiro se não houver casas decimais
        else:
            return num  # Retorna como float

    def reset(self):
        # Reseta as variáveis internas da calculadora
        self.operator = "+"  # Define o operador padrão
        self.operand1 = 0  # Reseta o primeiro operando
        self.new_operand = True  # Indica que um novo operando pode ser inserido


def main(page: ft.Page):
    page.title = "Calc App"  # Define o título da página
    # Cria a instância da calculadora
    calc = CalculatorApp()
    # Adiciona o controle principal da calculadora à página
    page.add(calc)


ft.app(target=main)  # Inicia a aplicação