import customtkinter as ctk
from database import Database
from ui import TelaCadastro

def main():
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    db = Database()
    app = TelaCadastro(db)
    app.mainloop()

    if __name__ == "_main_":
        main()