import customtkinter as ctk
from tkinter import ttk
from PIL import Image, ImageTk
from user_operations import UserOperations
import os
import sys

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

class TelaCadastro(ctk.CTk):
    def __init__(self, db):
        super().__init__()
        self.db = db
        self.user_operations = UserOperations(db, self)
        self.setup_ui()
        self.selected_user = None
        self.set_icon()

    def set_icon(self):
        icon_path = resource_path("inicio.ico")
        try:
            self.iconbitmap(icon_path)
        except:
            print(f"Não foi possível carregar o ícone: {icon_path}")

    def setup_ui(self):
        self.title("Cadastro e Lista de Usuários")
        self.geometry("600x850")

        try:
            icon_image = Image.open(resource_path("inicio.png"))
            icon_photo = ImageTk.PhotoImage(icon_image)
            self.iconphoto(False, icon_photo)
        except Exception as e:
            print(f"Não foi possível carregar o ícone padrão: {e}")

        self.frame = ctk.CTkFrame(self)
        self.frame.pack(pady=10, padx=10, fill="both", expand=True)

        self.label = ctk.CTkLabel(self.frame, text="Cadastro de Usuários", font=("Roboto", 24))
        self.label.pack(pady=10)

        self.nome_entry = ctk.CTkEntry(self.frame, placeholder_text="Nome")
        self.nome_entry.pack(pady=10, padx=10, fill="x")

        self.button_frame = ctk.CTkFrame(self.frame)
        self.button_frame.pack(pady=5)

        self.cadastrar_btn = ctk.CTkButton(self.button_frame, text="Cadastrar", 
                                           fg_color="green", hover_color="darkgreen", 
                                           command=self.user_operations.cadastrar)
        self.cadastrar_btn.pack(side="left", padx=5)

        self.atualizar_btn = ctk.CTkButton(self.button_frame, text="Atualizar", 
                                           fg_color="blue", hover_color="darkblue", 
                                           command=self.user_operations.atualizar_usuario)
        self.atualizar_btn.pack(side="left", padx=5)

        self.excluir_btn = ctk.CTkButton(self.button_frame, text="Excluir", 
                                         fg_color="red", hover_color="darkred", 
                                         command=self.user_operations.excluir_usuario)
        self.excluir_btn.pack(side="left", padx=5)

        style = ttk.Style()
        style.configure("Treeview.Heading", font=("Roboto", 10, "bold"))

        self.tree = ttk.Treeview(self.frame, columns=("ID", "Nome"), show="headings")
        self.tree.heading("ID", text="ID", anchor="center")
        self.tree.heading("Nome", text="Nome", anchor="center")
        self.tree.column("ID", width=50, anchor="center")
        self.tree.column("Nome", width=400, anchor="center")
        self.tree.pack(pady=10, padx=10, fill="both", expand=True)

        self.tree.bind("<<TreeviewSelect>>", self.on_user_select)

        self.carregar_dados()

    def carregar_dados(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for row in self.db.get_all_users():
            self.tree.insert("", "end", values=row)

    def on_user_select(self, event):
        selected_items = self.tree.selection()
        if selected_items:
            item = selected_items[0]
            self.selected_user = self.tree.item(item, "values")
            self.nome_entry.delete(0, "end")
            self.nome_entry.insert(0, self.selected_user[1])