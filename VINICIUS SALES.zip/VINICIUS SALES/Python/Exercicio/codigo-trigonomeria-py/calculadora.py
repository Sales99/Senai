import math

def calcular_trigonometria(angulo):
    """
    Realiza o cálculo dos valores trigonométricos (seno, cosseno e tangente) do ângulo fornecido.
    """
    try:
        radiano = math.radians(angulo)  # Converte o ângulo de graus para radianos

        # Calcula os valores trigonométricos
        seno = math.sin(radiano)
        cosseno = math.cos(radiano)
        tangente = math.tan(radiano)

        return seno, cosseno, tangente
    except ValueError:
        # Em caso de erro, retorna uma tupla com 'Erro'
        return "Erro", "Erro", "Erro"