import tkinter as tk  # Importa a biblioteca Tkinter para a criação da interface gráfica
from PIL import Image, ImageTk  # Importa as classes Image e ImageTk da biblioteca PIL para manipulação de imagens
import os  # Importa a biblioteca para operações com o sistema de arquivos
import sys  # Importa a biblioteca sys para manipulação de variáveis e funções do sistema
from calculadora import calcular_trigonometria  # Importa a função de cálculo

def resource_path(relative_path):
    """Obtém o caminho absoluto para o recurso."""
    try:
        base_path = sys._MEIPASS  # PyInstaller cria um diretório temporário
    except Exception:
        base_path = os.path.abspath(".")  # Caso não estiver executando pelo PyInstaller
    return os.path.join(base_path, relative_path)  # Retorna o caminho completo do arquivo

def calcular():
    """Realiza o cálculo e atualiza a interface com os resultados."""
    try:
        angulo = float(entrada_angulo.get())
        seno, cosseno, tangente = calcular_trigonometria(angulo)

        # Exibe os resultados formatados com 3 casas decimais
        resultado_seno.config(text=f"{seno:.3f}")
        resultado_cosseno.config(text=f"{cosseno:.3f}")
        resultado_tangente.config(text=f"{tangente:.3f}")
    except ValueError:
        # Exibe "Erro" nas labels em caso de entrada inválida
        resultado_seno.config(text="Erro")
        resultado_cosseno.config(text="Erro")
        resultado_tangente.config(text="Erro")

def limpar():
    """Limpa a entrada e os resultados."""
    entrada_angulo.delete(0, tk.END)
    resultado_seno.config(text="")
    resultado_cosseno.config(text="")
    resultado_tangente.config(text="")

def validar_entrada(texto):
    """Valida a entrada do usuário."""
    if texto.isdigit() or texto == "":
        if texto == "":
            return True
        valor = int(texto)
        return 0 <= valor <= 90
    return False

# Configuração da janela principal
janela = tk.Tk()
janela.title("Calculadora Trigonométrica")
janela.geometry("400x550")
janela.configure(bg="#f0f0f0")

# Carregar e definir o ícone da janela
try:
    icon_path = resource_path("seno.png")
    icone = Image.open(icon_path)
    icone = ImageTk.PhotoImage(icone)
    janela.iconphoto(True, icone)
except FileNotFoundError:
    print("Imagem 'seno.png' não encontrada para o ícone")

# Imagem seno2.png
try:
    imagem_path = resource_path("seno2.png")
    imagem = Image.open(imagem_path)
    imagem = imagem.resize((380, 200), Image.LANCZOS)
    foto = ImageTk.PhotoImage(imagem)
    label_imagem = tk.Label(janela, image=foto, bg="#f0f0f0", borderwidth=0)
    label_imagem.image = foto
    label_imagem.pack(pady=10)
except FileNotFoundError:
    print("Imagem 'seno2.png' não encontrada")

# Entrada do ângulo
frame_entrada = tk.Frame(janela, bg="#f0f0f0")
frame_entrada.pack(pady=10)

label_angulo = tk.Label(frame_entrada, text="Ângulo (0 à 90):", font=("Arial", 14), bg="#f0f0f0")
label_angulo.pack(pady=5)

validacao = janela.register(validar_entrada)
entrada_angulo = tk.Entry(frame_entrada, justify='center', font=("Arial", 16), validate="key", validatecommand=(validacao, "%P"))
entrada_angulo.pack()

linha = tk.Frame(frame_entrada, bg="black", height=1, width=entrada_angulo.winfo_reqwidth())
linha.pack(pady=(0, 5))

# Botões
frame_botoes = tk.Frame(janela, bg="#f0f0f0")
frame_botoes.pack(pady=20)

botao_calcular = tk.Button(frame_botoes, text="Calcular", command=calcular, font=("Arial", 12), bg="#d0d0d0", relief='flat', bd=0, highlightthickness=0)
botao_calcular.pack(side=tk.LEFT, padx=10)

botao_limpar = tk.Button(frame_botoes, text="Limpar", command=limpar, font=("Arial", 12), bg="#d0d0d0", relief='flat', bd=0, highlightthickness=0)
botao_limpar.pack(side=tk.RIGHT, padx=10)

# Resultados
frame_resultados = tk.Frame(janela, bg="#f0f0f0")
frame_resultados.pack(pady=10)

label_seno = tk.Label(frame_resultados, text="Seno:", font=("Arial", 12), bg="#f0f0f0")
label_seno.grid(row=0, column=0, padx=10, pady=5, sticky='e')
resultado_seno = tk.Label(frame_resultados, text="", font=("Arial", 12, 'bold'), fg='red', bg="#f0f0f0")
resultado_seno.grid(row=0, column=1, padx=10, pady=5, sticky='w')

label_cosseno = tk.Label(frame_resultados, text="Cosseno:", font=("Arial", 12), bg="#f0f0f0")
label_cosseno.grid(row=1, column=0, padx=10, pady=5, sticky='e')
resultado_cosseno = tk.Label(frame_resultados, text="", font=("Arial", 12, 'bold'), fg='red', bg="#f0f0f0")
resultado_cosseno.grid(row=1, column=1, padx=10, pady=5, sticky='w')

label_tangente = tk.Label(frame_resultados, text="Tangente:", font=("Arial", 12), bg="#f0f0f0")
label_tangente.grid(row=2, column=0, padx=10, pady=5, sticky='e')
resultado_tangente = tk.Label(frame_resultados, text="", font=("Arial", 12, 'bold'), fg='red', bg="#f0f0f0")
resultado_tangente.grid(row=2, column=1, padx=10, pady=5, sticky='w')

# Iniciar a janela
janela.mainloop()
