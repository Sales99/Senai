import flet as ft # Importa a biblioteca Flet para criar interfaces gráficas

# Classe que representa uma mensagem
class Message:
    def __init__(self, user_name: str, text: str, message_type: str):
        self.user_name = user_name  # Nome do usuário que enviou a mensagem
        self.text = text  # Texto da mensagem
        self.message_type = message_type  # Tipo da mensagem (login ou chat)

# Classe que representa uma mensagem no chat na interface
class ChatMessage(ft.Row):
    def __init__(self, message: Message):
        super().__init__()  # Chama o construtor da classe pai (ft.Row)
        self.vertical_alignment = ft.CrossAxisAlignment.START  # Alinha verticalmente o conteúdo no início
        self.controls = [  # Define os componentes da mensagem
            ft.CircleAvatar(
                content=ft.Text(self.get_initials(message.user_name)),  # Mostra as iniciais do usuário
                color=ft.colors.WHITE,  # Cor do texto do avatar
                bgcolor=self.get_avatar_color(message.user_name),  # Cor de fundo do avatar
            ),
            ft.Column(  # Coluna para mostrar o nome e texto da mensagem
                [
                    ft.Text(message.user_name, weight="bold"),  # Nome do usuário em negrito
                    ft.Text(message.text, selectable=True),  # Texto da mensagem
                ],
                spacing=5,  # Espaçamento entre os elementos da coluna
            )
        ]

    def get_initials(self, user_name: str):
        if user_name:
            return user_name[:1].capitalize()  # Retorna a primeira letra em maiúscula
        else:
            return "U"  # Retorna inicial de "Unknown" se não houver nome

    def get_avatar_color(self, user_name: str):
        # Retorna uma cor para o avatar com base no nome do usuário
        colors_lookup = [
            ft.colors.AMBER,
            ft.colors.BLUE,
            ft.colors.BROWN,
            ft.colors.CYAN,
            ft.colors.GREEN,
            ft.colors.INDIGO,
            ft.colors.LIME,
            ft.colors.ORANGE,
            ft.colors.PINK,
            ft.colors.PURPLE,
            ft.colors.RED,
            ft.colors.TEAL,
        ]
        return colors_lookup[hash(user_name) % len(colors_lookup)]

# Função principal que configura a página do chat
def main(page: ft.Page):
    page.horizontal_alignment = ft.CrossAxisAlignment.STRETCH  # Alinha horizontalmente os componentes
    page.title = "Flet Chat"  # Título da página

    # Função chamada quando o usuário clica em "join chat"
    def join_chat_click(e):
        if not join_user_name.value:  # Verifica se o nome do usuário está vazio
            join_user_name.error_text = "Name cannot be blank!"  # Exibe erro
            join_user_name.update()
            return
        page.session.set("user_name", join_user_name.value)  # Define o nome do usuário
        page.dialog.open = False  # Fecha o diálogo
        page.update()
        page.pubsub.send_all(
            Message(
                user_name=join_user_name.value,
                text=f"{join_user_name.value} has joined the chat.",
                message_type="login_message",
            )
        )

    # Função chamada ao enviar uma nova mensagem
    def send_message_click(e):
        if new_message.value == "":  # Verifica se o campo não está vazio
            return
        page.pubsub.send_all(
            Message(
                user_name=page.session.get("user_name"),  # Nome do usuário da sessão
                text=new_message.value,  # Texto da nova mensagem
                message_type="chat_message",
            )
        )
        new_message.value = ""  # Limpa o campo de mensagem
        page.update()

    # Função chamada ao receber uma mensagem
    def on_message(message: Message):
        if message.message_type == "login_message":
            chat.controls.append(
                ft.Text(message.text, italic=True, color=ft.colors.BLACK45, size=12)  # Mensagem de login
            )
        else:
            chat.controls.append(ChatMessage(message))  # Cria um novo objeto ChatMessage
        page.update()

    page.pubsub.subscribe(on_message)  # Inscreve a função on_message para receber mensagens

    # Diálogo para solicitar o nome do usuário
    join_user_name = ft.TextField(
        label="Enter your name to join the chat",  # Rótulo do campo
        autofocus=True,  # Foca automaticamente no campo ao abrir
        on_submit=join_chat_click,  # Chama a função ao pressionar Enter
    )
    page.dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text("Welcome!"),  # Título do diálogo
        content=ft.Column([join_user_name], width=500, height=70, tight=True),  # Conteúdo do diálogo
        actions=[ft.ElevatedButton(text="Join chat", on_click=join_chat_click)],  # Botão de ação
        actions_alignment=ft.MainAxisAlignment.END,  # Alinha ações ao final
    )
    page.dialog.open = True

    # Componente que mostra as mensagens do chat
    chat = ft.ListView(
        expand=True,  # Expande para ocupar espaço disponível
        spacing=10,  # Espaçamento entre mensagens
        auto_scroll=True,  # Rolagem automática para novas mensagens
    )

    # Campo para enviar novas mensagens
    new_message = ft.TextField(
        hint_text="Write a message...",  # Texto de dica
        autofocus=True,  # Foca automaticamente no campo ao abrir
        shift_enter=True,  # Permite quebra de linha com Shift + Enter
        min_lines=1,  # Número mínimo de linhas
        max_lines=5,  # Número máximo de linhas
        filled=True,  # Preenchido
        expand=True,  # Expande para ocupar espaço
        on_submit=send_message_click,  # Chama a função ao pressionar Enter
    )

    # Adiciona todos os componentes à página
    page.add(
        ft.Container(
            content=chat,  # Adiciona o chat ao container
            border=ft.border.all(1, ft.colors.OUTLINE),  # Borda do container
            border_radius=8,  # Raio da borda
            padding=10,  # Preenchimento interno
            expand=True,  # Expande o container
        ),
        ft.Row(
            [
                new_message,  # Campo de nova mensagem
                ft.IconButton(
                    icon=ft.icons.SEND_ROUNDED,  # Ícone de envio
                    tooltip="Send message",  # Dica ao passar o mouse
                    on_click=send_message_click,  # Chama a função ao clicar
                ),
            ],
        ),
    )

# Executa a aplicação com a função main como alvo
ft.app(target=main)