import customtkinter as ctk

ctk.set_appearance_mode("light")

# Parãmetros da janela
janela = ctk.CTk()
janela.title("Cadastro")
janela.geometry("350x420")

label_titulo = ctk.CTkLabel(janela, text="Cadastro", font=("Consolas", 28, "bold"))
label_titulo.pack(padx=10, pady=20)

#Função cadastrar
def cadastrar():
    nome_in = nome.get()
    idade_in = idade.get()
    cidade_in = cidade.get()

    label_mensagem.configure(text=f"Nome: {nome_in}\n"
                             f"Idade: {idade_in}\n"
                             f"Cidade: {cidade_in}\n")
    
# Função Cancelar
def cancelar():
    label_mensagem.configure(text="")
    nome.delete(0, ctk.END)
    idade.delete(0, ctk.END)
    cidade.delete(0, ctk.END)

# Campos do cadastro 
nome = ctk.CTkEntry(janela, width=260, height=35, font=("Consolas", 12), placeholder_text="Nome...")
nome.pack(padx=10, pady=15)

idade = ctk.CTkEntry(janela, width=260, height=35, font=("Consolas", 12), placeholder_text="Idade...")
idade.pack(padx=10, pady=15)

cidade = ctk.CTkEntry(janela, width=260, height=35, font=("Consolas", 12), placeholder_text="Cidade...")
cidade.pack(padx=10, pady=15)

# Container Botões 
frame_btn = ctk.CTkFrame(janela)
frame_btn.pack(padx=10)

# Botões
btn_cadastrar = ctk.CTkButton(frame_btn, text="Cadastrar", font=("Consolas", 14, "bold"),
                              width=100, height=50, command=cadastrar)
btn_cadastrar.pack(padx=2, pady=5, side="left")

btn_cancelar = ctk.CTkButton(frame_btn, text="Cancelar", font=("Consolas", 14, "bold"),
                              width=100, height=50, command=cancelar)
btn_cancelar.pack(padx=2, pady=5, side="left")

label_mensagem = ctk.CTkLabel(janela, text="", font=("Consolas", 14, "bold"), text_color="blue")
label_mensagem.pack(padx=10, pady=20)

janela.mainloop()

    