import customtkinter as ctk  # Importação da biblioteca Customtkinter
from tkinter import messagebox  # Importação dos componentes adicionais (caixa de mensagem)

ctk.set_appearance_mode("dark")  # Definir o tema como escuro

# Parâmetros da janela
janela = ctk.CTk()
janela.title("Login")
janela.geometry("350x350")

# Container principal de tela
frame_tela = ctk.CTkFrame(janela)
frame_tela.pack(padx=15, pady=15, fill="both", expand=True)

label_titulo = ctk.CTkLabel(frame_tela, text="Login", font=("Consolas", 28, "bold"))
label_titulo.pack(padx=10, pady=20)

# Campos de Cadastro (e-mail e senha)
email = ctk.CTkEntry(frame_tela, width=260, height=35, font=("Consolas", 12), placeholder_text="e-mail")
email.pack(padx=10, pady=5)

senha = ctk.CTkEntry(frame_tela, width=260, height=35, font=("Consolas", 12), placeholder_text="Senha", show="*")
senha.pack(padx=10, pady=10)

# Container dos botões
frame_btn = ctk.CTkFrame(frame_tela)
frame_btn.pack(padx=10)

# Função Logar usuário
def logar_usuario():
    # Variáveis
    user = "calebros"
    email_in = email.get()
    senha_in = senha.get()

    # Verifica se o usuário e senha são valores válidos
    if email_in == "sales@gmail.com" and senha_in == "sales":
        label_mensagem.configure(text=f"Bem-vindo, {user}!", font=("Consolas", 14, "bold"), text_color="blue")
        messagebox.showinfo("Atenção!", "Operação concluída!")  # Abertura da caixa de mensagem
        email.delete(0, ctk.END)
        senha.delete(0, ctk.END)
        janela.destroy()  # Função para fechar o programa
    else:
        label_mensagem.configure(text="Usuário e/ou senha inválido(s).", font=("Consolas", 14, "bold"), text_color="red")

# Função Cancelar
def cancelar():
    messagebox.showinfo("Atenção!", "Operação cancelada!")  # Abertura da caixa de mensagem
    email.delete(0, ctk.END)
    senha.delete(0, ctk.END)

# Botão Login
btn_login = ctk.CTkButton(frame_btn, text="Login", font=("Consolas", 14, "bold"), width=100, height=50, fg_color="green", command=logar_usuario)
btn_login.pack(padx=5, pady=5, side="left")

# Botão Cancelar
btn_cancelar = ctk.CTkButton(frame_btn, text="Cancelar", font=("Consolas", 14, "bold"), width=100, height=50, fg_color="gray", command=cancelar)
btn_cancelar.pack(padx=5, pady=5, side="left")

# Exibir a mensagem na tela
label_mensagem = ctk.CTkLabel(frame_tela, text="")
label_mensagem.pack(padx=10, pady=20)

janela.mainloop()
